valor = int(input('Insira um valor: '))

print(f'O dobro do valor {valor} é {valor * 2}')
print(f'O triplo do valor {valor} é {valor * 3}')
print(f'O valor ao quadrado de {valor} é {valor ** 2}')
print(f'A raiz quadrada do valor {valor} é {valor ** 0.5}')
print(f'A raíz cúbica do valor {valor} é {valor ** (1/3)}')

