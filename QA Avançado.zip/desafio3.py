nome = 'Paula Martins'
mes = 'Janeiro'
valor_compra = 500
desconto = 10
cupom = 'PAULAÉ10'

mensagem = 'Olá, {nome}. Em {mes} você realizou uma compra no valor de R$ {valor_compra:.2f} e ganhou um desconto de {desconto}% em sua próxima compra. Use o cupom {cupom}.'

print(mensagem)