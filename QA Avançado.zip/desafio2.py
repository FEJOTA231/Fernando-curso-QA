nome = input('Digite seu nome: ')
idade = int(input('Digite sua idade: '))

print(f'Olá, meu nome é {nome} e tenho {idade} anos.')