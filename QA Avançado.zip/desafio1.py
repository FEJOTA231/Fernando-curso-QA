print("Desafio do Caique")
print(145+234)